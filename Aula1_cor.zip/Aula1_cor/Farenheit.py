'''
Gabriella
 - sem erros
'''
# -*- coding: utf-8 -*-
print 'Esse programa converte a temperatura de Celsius para fahrenheit'
celsius  = 30.5     #Declarar celsius com um valor qualquer
fahrenheit = (celsius * (9./5)) + 32      #Escrever a fórmula para a conversão no formato python2
print "A temperatura em fahrenheit é", fahrenheit   #Mostrar a temperatura em fahrenheit
